//
//  CMUpdateManager.h
//  CMUpdateSDK
//
//  Created by code_xw on 2018/11/27.
//  Copyright © 2018年 code_xw. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CMUpdateInfoModel.h"
typedef NS_ENUM(NSUInteger, CMUpdateType) {
    CMUpdateType_NeedUpdate,
    CMUpdateType_ShouldUpdate,
    CMUpdateType_Other,
};
typedef NS_ENUM(NSUInteger, CMUpdateSDKMode) {
    CMUpdateSDKMode_Release,
    CMUpdateSDKMode_Debug,
//    CMUpdateSDKMode_Staging, 暂未开放
    
};
NS_ASSUME_NONNULL_BEGIN

@interface CMUpdateManager : NSObject
@property (nonatomic, readonly) CMUpdateSDKMode sdkMode;
@property (nonatomic, readonly) BOOL policy;

+ (instancetype)initializeWithPID:(NSString *)PID userID:(nullable NSString *)UserID;
+ (instancetype)manager;
- (void)setMode:(CMUpdateSDKMode)Mode;
/**
 是否参与灰度
 */
- (void)policyMode:(BOOL)Policy;

/**
 版本检测(内部已做弹系统 Alert 处理)
 */
- (void)checkVersion;

/**
 返回版本检测接口的信息,用作自处理;
 */
- (void)loadVersionInfo:(void(^)(CMUpdateInfoModel * _Nullable infoModel, NSError * _Nullable erro))CompletionHandler;
@end

NS_ASSUME_NONNULL_END
