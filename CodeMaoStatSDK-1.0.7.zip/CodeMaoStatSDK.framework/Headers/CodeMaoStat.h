// Countly.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.

#import <Foundation/Foundation.h>
#import "CodeMaoStatConfig.h"

//NS_ASSUME_NONNULL_BEGIN


//FIXME: remober update version
extern NSString* const kCodeMaoStatVersion; //1.0.7
extern NSString* const kCodeMaoStatHost;

typedef NS_ENUM(NSUInteger, CodeMaoStatReportType) {
    CodeMaoStatReportTypeEvent,//用户事件
    CodeMaoStatReportTypeCrash//程序崩溃
};


typedef NS_ENUM(NSUInteger, EVENT) {   //事件ID预定义
    EVENT_CLICK      = 1001,//点击事件
    EVENT_EXP        = 1001,//曝光事件
    EVENT_SLIDE      = 1003,//滑动事件
    EVENT_OTHER      = 0001,//其他事件
    EVENT_REG        = 2001,//注册账号
    EVENT_SIGN       = 2002,//登陆账号
    EVENT_SIGNOUT    = 2003,//退出账号
    EVENT_BINDPHONE  = 2004,//绑定手机
    EVENT_CHANGEPWD  = 2005,//改密码
    EVENT_PUSH_CLICK = 3001,//点击push
    EVENT_PUSH_EXP   = 3002,//push曝光
    EVENT_SHARE      = 4001,//分享
    EVENT_PAGE       = 1004,//页面跳转
    EVENT_BACK       = 1005,//返回上一级页面
    EVENT_SESSION    = 1006,//页面停留时长
    EVENT_PAY        = 5001,//支付
    EVENT_UNINSTALL  = 0002,//卸载
    EVENT_FEED       = 0003,//建议反馈
    EVENT_CRASH      = 0004,//crash
    EVENT_EXIT       = 0005//关闭app
};


@interface CodeMaoStat : NSObject
#pragma mark - Core


+ (instancetype)sharedInstance;



- (void)startWithConfig:(CodeMaoStatConfig *)config;


- (void)recordEvent:(NSString *)eventId;


- (void)recordEvent:(NSString *)eventId bizData:(NSDictionary * _Nullable)bizData;


@end
