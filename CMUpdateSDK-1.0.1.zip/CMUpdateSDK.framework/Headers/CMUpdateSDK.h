//
//  CMUpdateSDK.h
//  CMUpdateSDK
//
//  Created by code_xw on 2018/12/5.
//  Copyright © 2018年 code_xw. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CMUpdateSDK.
FOUNDATION_EXPORT double CMUpdateSDKVersionNumber;

//! Project version string for CMUpdateSDK.
FOUNDATION_EXPORT const unsigned char CMUpdateSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CMUpdateSDK/PublicHeader.h>
#import <CMUpdateSDK/CMUpdateManager.h>
#import <CMUpdateSDK/CMUpdateInfoModel.h>

