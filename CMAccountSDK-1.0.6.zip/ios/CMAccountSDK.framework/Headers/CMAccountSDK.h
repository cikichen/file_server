//
//  BCMLoginSDK.h
//  BCMLoginSDK
//
//  Created by CodeMao_xw on 2017/12/5.
//  Copyright © 2017年 CodeMao_xw. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BCMLoginSDK.
FOUNDATION_EXPORT double BCMLoginSDKVersionNumber;

//! Project version string for BCMLoginSDK.
FOUNDATION_EXPORT const unsigned char BCMLoginSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BCMLoginSDK/PublicHeader.h>

#import <CMAccountSDK/CodeMaoAccount.h>
#import <CMAccountSDK/CMLoginApiObject.h>
#import <CMAccountSDK/CMLoginSDKConfig.h>

// CMShareSDK Source Code
#import <CMAccountSDK/CMShareManager.h>
#import <CMAccountSDK/CMShareModel.h>
#import <CMAccountSDK/CMShareEnums.h>
