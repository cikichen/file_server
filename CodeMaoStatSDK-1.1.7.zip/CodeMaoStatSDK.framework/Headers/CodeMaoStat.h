// Countly.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.

#import <Foundation/Foundation.h>
#import "CodeMaoStatConfig.h"

//NS_ASSUME_NONNULL_BEGIN


//FIXME: remober update version
extern NSString* const kCodeMaoStatVersion; //1.1.7
extern NSString* const kCodeMaoStatHost;

typedef NS_ENUM(NSUInteger, CodeMaoStatReportType) {
    CodeMaoStatReportTypeEvent,//用户事件
    CodeMaoStatReportTypeCrash//程序崩溃
};


//事件ID预定义
//    EVENT_CLICK      //点击事件
//    EVENT_EXP        //曝光事件
//    EVENT_SLIDE      //滑动事件
//    EVENT_OTHER      //其他事件
//    EVENT_REG        //注册账号
//    EVENT_SIGN       //登陆账号
//    EVENT_SIGNOUT    //退出账号
//    EVENT_BINDPHONE  //绑定手机
//    EVENT_CHANGEPWD  //改密码
//    EVENT_PUSH_CLICK //点击push
//    EVENT_PUSH_EXP   //push曝光
//    EVENT_SHARE      //分享
//    EVENT_PAGE       //页面跳转
//    EVENT_BACK       //返回上一级页面
//    EVENT_SESSION    //页面停留时长
//    EVENT_PAY        //支付
//    EVENT_UNINSTALL  //卸载
//    EVENT_FEED       //建议反馈
//    EVENT_CRASH      //crash
//    EVENT_EXIT       //关闭app



@interface CodeMaoStat : NSObject
#pragma mark - Core


+ (instancetype)sharedInstance;



- (void)startWithConfig:(CodeMaoStatConfig *)config;


- (void)recordEvent:(NSString *)eventId;


- (void)recordEvent:(NSString *)eventId bizData:(NSDictionary * _Nullable)bizData;


@end
