# cm_module_demo

[![CI Status](http://img.shields.io/travis/chensiming/cm_module_demo.svg?style=flat)](https://travis-ci.org/chensiming/cm_module_demo)
[![Version](https://img.shields.io/cocoapods/v/cm_module_demo.svg?style=flat)](http://cocoapods.org/pods/cm_module_demo)
[![License](https://img.shields.io/cocoapods/l/cm_module_demo.svg?style=flat)](http://cocoapods.org/pods/cm_module_demo)
[![Platform](https://img.shields.io/cocoapods/p/cm_module_demo.svg?style=flat)](http://cocoapods.org/pods/cm_module_demo)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

cm_module_demo is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'cm_module_demo'
```

## Author

chensiming, chensiming@codemao.cn

## License

cm_module_demo is available under the MIT license. See the LICENSE file for more info.
