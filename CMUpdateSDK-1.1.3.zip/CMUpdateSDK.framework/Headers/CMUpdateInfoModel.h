//
//  CMUpdateInfoModel.h
//  CMUpdateSDK
//
//  Created by code_xw on 2018/11/27.
//  Copyright © 2018年 code_xw. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CMUpdateInfoModel : NSObject

/** 应用名 */
@property (nonatomic, copy) NSString * appName;
/** 新版本号(外部版本号) */
@property (nonatomic, copy) NSString * cm_newVersion;
/** 支持的最低设备版本 */
@property (nonatomic, copy) NSString * minVersion;
/** 更新日志 */
@property (nonatomic, copy) NSString * updateDesc;
/** 新版本地址 */
@property (nonatomic, copy) NSString * pkgUrl;
/** 是否强制更新 */
@property (nonatomic) BOOL forceUpdate;
@end

NS_ASSUME_NONNULL_END
